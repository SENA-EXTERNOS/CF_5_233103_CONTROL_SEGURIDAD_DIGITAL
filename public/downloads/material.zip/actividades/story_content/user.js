function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64KIm4gXrIK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

